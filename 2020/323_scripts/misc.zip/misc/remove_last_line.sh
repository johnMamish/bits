#!/bin/bash

sed -i '$ d' $1 
